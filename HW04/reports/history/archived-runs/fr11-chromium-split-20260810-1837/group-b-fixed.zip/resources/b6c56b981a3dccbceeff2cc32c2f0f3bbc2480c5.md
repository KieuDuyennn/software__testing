# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: fr11_order_history\fr11.order-history.spec.ts >> FR-11 Order history view >> FR11-TC-33 [edge] a negative order total must not be displayed as a price
- Location: automation\tests\fr11_order_history\fr11.order-history.spec.ts:320:5

# Error details

```
Error: FR11-TC-33: money cell renders "-1,000,000 ₫", which must not contain "-" - the seeded total was -1000000

expect(received).not.toContain(expected) // indexOf

Expected substring: not "-"
Received string:        "-1,000,000 ₫"
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - link "EShop" [ref=e5] [cursor=pointer]:
      - /url: /
    - navigation [ref=e6]:
      - link "Giỏ hàng" [ref=e7] [cursor=pointer]:
        - /url: /cart
      - generic [ref=e8]:
        - link "Chào, Test User" [ref=e9] [cursor=pointer]:
          - /url: /profile
        - button "Thoát" [ref=e10] [cursor=pointer]
  - main [ref=e11]:
    - generic [ref=e12]:
      - generic [ref=e13]:
        - heading "Hồ sơ của bạn" [level=2] [ref=e14]
        - generic [ref=e15]:
          - generic [ref=e16]:
            - generic [ref=e17]: Email (Không đổi)
            - textbox [disabled] [ref=e18]: test@eshop.com
          - generic [ref=e19]:
            - generic [ref=e20]: Họ Tên
            - textbox [ref=e21]: Test User
          - generic [ref=e22]:
            - generic [ref=e23]: Số điện thoại
            - 'textbox "VD: 0912345678" [ref=e24]'
          - generic [ref=e25]:
            - generic [ref=e26]: Địa chỉ giao hàng
            - textbox "Nhập địa chỉ của bạn" [ref=e27]
          - button "Cập nhật" [ref=e28] [cursor=pointer]
      - generic [ref=e29]:
        - heading "Lịch sử đơn hàng" [level=2] [ref=e30]
        - table [ref=e31]:
          - rowgroup [ref=e32]:
            - row [ref=e33]:
              - columnheader "Mã ĐH" [ref=e34]
              - columnheader "Ngày đặt" [ref=e35]
              - columnheader "Tổng tiền" [ref=e36]
              - columnheader "Trạng thái" [ref=e37]
              - columnheader "Thao tác" [ref=e38]
          - rowgroup [ref=e39]:
            - row [ref=e40]:
              - cell "#8" [ref=e41]
              - cell "8/10/2026" [ref=e42]
              - cell "-1,000,000 ₫" [ref=e43]
              - cell "Chờ xác nhận" [ref=e44]
              - cell [ref=e45]:
                - button "Hủy đơn" [ref=e46] [cursor=pointer]
            - row [ref=e47]:
              - cell "#7" [ref=e48]
              - cell "8/10/2026" [ref=e49]
              - cell "0 ₫" [ref=e50]
              - cell "Chờ xác nhận" [ref=e51]
              - cell [ref=e52]:
                - button "Hủy đơn" [ref=e53] [cursor=pointer]
            - row [ref=e54]:
              - cell "#6" [ref=e55]
              - cell "8/10/2026" [ref=e56]
              - cell "NaN ₫" [ref=e57]
              - cell "Chờ xác nhận" [ref=e58]
              - cell [ref=e59]:
                - button "Hủy đơn" [ref=e60] [cursor=pointer]
            - row [ref=e61]:
              - cell "#5" [ref=e62]
              - cell "8/10/2026" [ref=e63]
              - cell "1,000,000 ₫" [ref=e64]
              - cell "Đã giao" [ref=e65]
              - cell [ref=e66]
            - row [ref=e67]:
              - cell "#4" [ref=e68]
              - cell "8/10/2026" [ref=e69]
              - cell "1,000,000 ₫" [ref=e70]
              - cell "Đã hủy" [ref=e71]
              - cell [ref=e72]
            - row [ref=e73]:
              - cell "#2" [ref=e74]
              - cell "8/10/2026" [ref=e75]
              - cell "1,000,000 ₫" [ref=e76]
              - cell "Đã hủy" [ref=e77]
              - cell [ref=e78]
            - row [ref=e79]:
              - cell "#1" [ref=e80]
              - cell "8/10/2026" [ref=e81]
              - cell "1,000,000 ₫" [ref=e82]
              - cell "Đã hủy" [ref=e83]
              - cell [ref=e84]
  - contentinfo [ref=e85]: © 2026 EShop SUT. Dành cho mục đích kiểm thử.
```

# Test source

```ts
  715 |             new Set(classes).size,
  716 |             `${row.tc_id}: the five statuses do not render in ${row.expect_distinct_badge_count} ` +
  717 |             `distinct colours - got ${JSON.stringify(classes)}`,
  718 |           ).toBe(row.expect_distinct_badge_count);
  719 |           break;
  720 |         }
  721 | 
  722 |         case 'cancel_visibility': {
  723 |           const counts = await Promise.all(
  724 |             seededIds.map((id) => orderHistoryPage.cancelButton(id).count()),
  725 |           );
  726 |           const shown = counts.filter((c) => c > 0).length;
  727 |           expect(
  728 |             shown,
  729 |             `${row.tc_id}: cancel offered on ${shown} of the ${seededIds.length} seeded ` +
  730 |             `statuses, expected ${row.expect_cancel_count}`,
  731 |           ).toBe(row.expect_cancel_count);
  732 |           break;
  733 |         }
  734 | 
  735 |         case 'ordering': {
  736 |           // Pattern 3. Asserted on the id column: the date column cannot witness this -
  737 |           // see expectSortedDescByNumber for the measured reason.
  738 |           const ids = await orderHistoryPage.orderIds();
  739 |           expectSortedDescByNumber(ids, `${row.tc_id} ${row.expect_sorted_desc_by}`);
  740 |           // And the ids this run seeded must appear newest-first among themselves.
  741 |           const seededInOrder = ids.filter((id) => seededIds.includes(id));
  742 |           expect(
  743 |             seededInOrder,
  744 |             `${row.tc_id}: the orders seeded by this run are not newest-first`,
  745 |           ).toEqual([...seededIds].reverse());
  746 |           break;
  747 |         }
  748 | 
  749 |         case 'date_valid': {
  750 |           const orderId = seededIds[0];
  751 |           const rendered = (await orderHistoryPage.cellOf(orderId, 2).innerText()).trim();
  752 | 
  753 |           // Pattern 1: the cell must say something, and must not say "Invalid Date".
  754 |           expect(rendered, `${row.tc_id}: date cell is empty`).not.toBe('');
  755 |           expect(rendered, `${row.tc_id}: date rendered as "Invalid Date"`).not.toContain('Invalid');
  756 | 
  757 |           /*
  758 |            * Pattern 3: the cell must be THIS order's date.
  759 |            *
  760 |            * Deliberately NOT `Date.parse(rendered)`. `toLocaleDateString()` emits a
  761 |            * localized string, and Node's parser reads `10/08/2026` as 10 August in
  762 |            * en-US order while the engine may have written it as 8 October - so the
  763 |            * check would either fail on a correct date or pass on a wrong one,
  764 |            * differently per browser. That is a false-fail generator across the three
  765 |            * required engines, not a test.
  766 |            *
  767 |            * Instead: take `created_at` from the API, split it into calendar parts IN
  768 |            * THE BROWSER (its timezone is what the rendering used), and require the
  769 |            * cell to contain each part. Comparing parts rather than a formatted string
  770 |            * is order-agnostic, so dd/MM/yyyy and M/d/yyyy both satisfy it while a
  771 |            * genuinely wrong date does not.
  772 |            */
  773 |           const seeded = (await api.myOrders(request, ownerToken)).find((o) => o.id === orderId);
  774 |           expect(seeded, `${row.tc_id}: seeded order #${orderId} not returned by my-orders`)
  775 |             .toBeDefined();
  776 | 
  777 |           const parts = await page.evaluate((createdAt: string) => {
  778 |             const date = new Date(createdAt);
  779 |             return Number.isNaN(date.getTime()) ? null : {
  780 |               year: String(date.getFullYear()),
  781 |               month: String(date.getMonth() + 1),
  782 |               day: String(date.getDate()),
  783 |             };
  784 |           }, seeded!.created_at);
  785 | 
  786 |           expect(
  787 |             parts,
  788 |             `${row.tc_id}: the browser cannot parse created_at "${seeded!.created_at}" at all, ` +
  789 |             `so the rendered cell cannot be correct either`,
  790 |           ).not.toBeNull();
  791 | 
  792 |           for (const [name, value] of Object.entries(parts!)) {
  793 |             // Zero-padded and unpadded forms both count: "8" must match "08".
  794 |             const padded = value.padStart(2, '0');
  795 |             expect(
  796 |               rendered.includes(value) || rendered.includes(padded),
  797 |               `${row.tc_id}: date cell "${rendered}" does not contain the ${name} ` +
  798 |               `(${value}) of this order's created_at "${seeded!.created_at}"`,
  799 |             ).toBe(true);
  800 |           }
  801 |           break;
  802 |         }
  803 | 
  804 |         case 'money_render': {
  805 |           const rendered = (await orderHistoryPage.cellOf(seededIds[0], 3).innerText()).trim();
  806 |           if (row.expect_money_text !== undefined) {
  807 |             expect(rendered, `${row.tc_id}: money cell`).toBe(row.expect_money_text);
  808 |           }
  809 |           if (row.expect_money_not !== undefined) {
  810 |             expect(
  811 |               rendered,
  812 |               `${row.tc_id}: money cell renders "${rendered}", which must not contain ` +
  813 |               `"${row.expect_money_not}" - the seeded total was ` +
  814 |               `${JSON.stringify(row.seed_owner_orders![0].total_amount)}`,
> 815 |             ).not.toContain(row.expect_money_not);
      |                   ^ Error: FR11-TC-33: money cell renders "-1,000,000 ₫", which must not contain "-" - the seeded total was -1000000
  816 |           }
  817 |           break;
  818 |         }
  819 | 
  820 |         case 'cancel_click': {
  821 |           const id = seededIds[0];
  822 |           const buttonCount = await orderHistoryPage.cancelButton(id).count();
  823 | 
  824 |           if (row.expect_cancel_allowed) {
  825 |             expect(
  826 |               buttonCount,
  827 |               `${row.tc_id}: no cancel button on an order that should be cancellable`,
  828 |             ).toBe(1);
  829 |             await orderHistoryPage.cancelButton(id).click();
  830 |             if (row.expect_dialog !== undefined) {
  831 |               await expect
  832 |                 .poll(() => dialogs, { message: `${row.tc_id}: no confirmation was shown` })
  833 |                 .toContain(row.expect_dialog);
  834 |             }
  835 |           } else if (buttonCount > 0) {
  836 |             // The requirement says this must be refused; the button being here at all is
  837 |             // already the symptom, so the click is what proves whether it is enforced.
  838 |             await orderHistoryPage.cancelButton(id).click();
  839 |           }
  840 | 
  841 |           // Pattern 1 + 3: what the row says afterwards is the requirement, whichever
  842 |           // route got us here - a refusal that still cancels the order fails here.
  843 |           await expect(
  844 |             orderHistoryPage.statusBadge(id),
  845 |             `${row.tc_id}: status after the cancel attempt (dialogs seen: ` +
  846 |             `${JSON.stringify(dialogs)})`,
  847 |           ).toHaveText(row.expect_label_after!);
  848 |           break;
  849 |         }
  850 | 
  851 |         case 'status_after_transition':
  852 |           await expect(
  853 |             orderHistoryPage.statusBadge(seededIds[0]),
  854 |             `${row.tc_id}: an order the user cancelled must not display as ` +
  855 |             `"${row.set_status}"`,
  856 |           ).toHaveText(row.expect_label_after!);
  857 |           if (row.expect_badge_class) {
  858 |             const badgeClass = await orderHistoryPage.badgeClassOf(seededIds[0]);
  859 |             for (const token of row.expect_badge_class.split(' ')) {
  860 |               expect(badgeClass, `${row.tc_id}: badge colour after the transition`).toContain(token);
  861 |             }
  862 |           }
  863 |           break;
  864 | 
  865 |         case 'load_error':
  866 |           if (row.intercept === 'my_orders_500') {
  867 |             // The requirement: a failure must be reported as a failure. Profile.jsx's
  868 |             // catch does setOrders([]), so the empty state is what actually appears -
  869 |             // asserting it must NOT appear is the falsifiable form of the requirement.
  870 |             await expect(
  871 |               orderHistoryPage.emptyState,
  872 |               `${row.tc_id}: the order fetch failed with 500, but the page tells the user ` +
  873 |               `they have no orders - an error is indistinguishable from an empty history`,
  874 |             ).toBeHidden();
  875 |           } else {
  876 |             // The fallback branch must render the payload it was given.
  877 |             await expect(
  878 |               orderHistoryPage.rowFor(424242),
  879 |               `${row.tc_id}: the documented res.data.orders fallback did not render`,
  880 |             ).toHaveCount(1);
  881 |           }
  882 |           break;
  883 | 
  884 |         case 'malformed_payload':
  885 |           await expect(
  886 |             orderHistoryPage.heading,
  887 |             `${row.tc_id}: malformed orders payload crashed the profile instead of ` +
  888 |             `showing a controlled error state`,
  889 |           ).toBeVisible();
  890 |           await expect(
  891 |             orderHistoryPage.emptyState,
  892 |             `${row.tc_id}: malformed data must not be presented as a genuine empty history`,
  893 |           ).toBeHidden();
  894 |           break;
  895 | 
  896 |         case 'own_rows_and_isolation':
  897 |           break; // handled above, where the payload is still in scope
  898 | 
  899 |         default:
  900 |           throw new Error(
  901 |             `${row.tc_id}: assert "${row.assert}" has no UI block - fix the data file`,
  902 |           );
  903 |       }
  904 |     });
  905 |   }
  906 | });
  907 | 
```