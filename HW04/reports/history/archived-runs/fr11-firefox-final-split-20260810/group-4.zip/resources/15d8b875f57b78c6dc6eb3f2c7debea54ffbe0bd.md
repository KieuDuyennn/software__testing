# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: fr11_order_history\fr11.order-history.spec.ts >> FR-11 Order history view >> FR11-TC-42 [edge] a nested orders value of the wrong type must not crash the profile
- Location: automation\tests\fr11_order_history\fr11.order-history.spec.ts:320:5

# Error details

```
Error: FR11-TC-42: malformed orders payload crashed the profile instead of showing a controlled error state

expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: 'Lịch sử đơn hàng' })
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - FR11-TC-42: malformed orders payload crashed the profile instead of showing a controlled error state with timeout 10000ms
  - waiting for getByRole('heading', { name: 'Lịch sử đơn hàng' })

```

# Test source

```ts
  789 |             `so the rendered cell cannot be correct either`,
  790 |           ).not.toBeNull();
  791 | 
  792 |           for (const [name, value] of Object.entries(parts!)) {
  793 |             // Zero-padded and unpadded forms both count: "8" must match "08".
  794 |             const padded = value.padStart(2, '0');
  795 |             expect(
  796 |               rendered.includes(value) || rendered.includes(padded),
  797 |               `${row.tc_id}: date cell "${rendered}" does not contain the ${name} ` +
  798 |               `(${value}) of this order's created_at "${seeded!.created_at}"`,
  799 |             ).toBe(true);
  800 |           }
  801 |           break;
  802 |         }
  803 | 
  804 |         case 'money_render': {
  805 |           const rendered = (await orderHistoryPage.cellOf(seededIds[0], 3).innerText()).trim();
  806 |           if (row.expect_money_text !== undefined) {
  807 |             expect(rendered, `${row.tc_id}: money cell`).toBe(row.expect_money_text);
  808 |           }
  809 |           if (row.expect_money_not !== undefined) {
  810 |             expect(
  811 |               rendered,
  812 |               `${row.tc_id}: money cell renders "${rendered}", which must not contain ` +
  813 |               `"${row.expect_money_not}" - the seeded total was ` +
  814 |               `${JSON.stringify(row.seed_owner_orders![0].total_amount)}`,
  815 |             ).not.toContain(row.expect_money_not);
  816 |           }
  817 |           break;
  818 |         }
  819 | 
  820 |         case 'cancel_click': {
  821 |           const id = seededIds[0];
  822 |           const buttonCount = await orderHistoryPage.cancelButton(id).count();
  823 | 
  824 |           if (row.expect_cancel_allowed) {
  825 |             expect(
  826 |               buttonCount,
  827 |               `${row.tc_id}: no cancel button on an order that should be cancellable`,
  828 |             ).toBe(1);
  829 |             await orderHistoryPage.cancelButton(id).click();
  830 |             if (row.expect_dialog !== undefined) {
  831 |               await expect
  832 |                 .poll(() => dialogs, { message: `${row.tc_id}: no confirmation was shown` })
  833 |                 .toContain(row.expect_dialog);
  834 |             }
  835 |           } else if (buttonCount > 0) {
  836 |             // The requirement says this must be refused; the button being here at all is
  837 |             // already the symptom, so the click is what proves whether it is enforced.
  838 |             await orderHistoryPage.cancelButton(id).click();
  839 |           }
  840 | 
  841 |           // Pattern 1 + 3: what the row says afterwards is the requirement, whichever
  842 |           // route got us here - a refusal that still cancels the order fails here.
  843 |           await expect(
  844 |             orderHistoryPage.statusBadge(id),
  845 |             `${row.tc_id}: status after the cancel attempt (dialogs seen: ` +
  846 |             `${JSON.stringify(dialogs)})`,
  847 |           ).toHaveText(row.expect_label_after!);
  848 |           break;
  849 |         }
  850 | 
  851 |         case 'status_after_transition':
  852 |           await expect(
  853 |             orderHistoryPage.statusBadge(seededIds[0]),
  854 |             `${row.tc_id}: an order the user cancelled must not display as ` +
  855 |             `"${row.set_status}"`,
  856 |           ).toHaveText(row.expect_label_after!);
  857 |           if (row.expect_badge_class) {
  858 |             const badgeClass = await orderHistoryPage.badgeClassOf(seededIds[0]);
  859 |             for (const token of row.expect_badge_class.split(' ')) {
  860 |               expect(badgeClass, `${row.tc_id}: badge colour after the transition`).toContain(token);
  861 |             }
  862 |           }
  863 |           break;
  864 | 
  865 |         case 'load_error':
  866 |           if (row.intercept === 'my_orders_500') {
  867 |             // The requirement: a failure must be reported as a failure. Profile.jsx's
  868 |             // catch does setOrders([]), so the empty state is what actually appears -
  869 |             // asserting it must NOT appear is the falsifiable form of the requirement.
  870 |             await expect(
  871 |               orderHistoryPage.emptyState,
  872 |               `${row.tc_id}: the order fetch failed with 500, but the page tells the user ` +
  873 |               `they have no orders - an error is indistinguishable from an empty history`,
  874 |             ).toBeHidden();
  875 |           } else {
  876 |             // The fallback branch must render the payload it was given.
  877 |             await expect(
  878 |               orderHistoryPage.rowFor(424242),
  879 |               `${row.tc_id}: the documented res.data.orders fallback did not render`,
  880 |             ).toHaveCount(1);
  881 |           }
  882 |           break;
  883 | 
  884 |         case 'malformed_payload':
  885 |           await expect(
  886 |             orderHistoryPage.heading,
  887 |             `${row.tc_id}: malformed orders payload crashed the profile instead of ` +
  888 |             `showing a controlled error state`,
> 889 |           ).toBeVisible();
      |             ^ Error: FR11-TC-42: malformed orders payload crashed the profile instead of showing a controlled error state
  890 |           await expect(
  891 |             orderHistoryPage.emptyState,
  892 |             `${row.tc_id}: malformed data must not be presented as a genuine empty history`,
  893 |           ).toBeHidden();
  894 |           break;
  895 | 
  896 |         case 'own_rows_and_isolation':
  897 |           break; // handled above, where the payload is still in scope
  898 | 
  899 |         default:
  900 |           throw new Error(
  901 |             `${row.tc_id}: assert "${row.assert}" has no UI block - fix the data file`,
  902 |           );
  903 |       }
  904 |     });
  905 |   }
  906 | });
  907 | 
```