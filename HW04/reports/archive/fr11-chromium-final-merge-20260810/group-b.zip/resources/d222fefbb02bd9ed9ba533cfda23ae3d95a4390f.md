# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: fr11_order_history\fr11.order-history.spec.ts >> FR-11 Order history view >> FR11-TC-34 [edge] a missing order total must not be silently displayed as 0 ₫
- Location: automation\tests\fr11_order_history\fr11.order-history.spec.ts:320:5

# Error details

```
Error: FR11-TC-34: money cell renders "0 ₫", which must not contain "0 ₫" - the seeded total was null

expect(received).not.toContain(expected) // indexOf

Expected substring: not "0 ₫"
Received string:        "0 ₫"
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - link "EShop" [ref=e5] [cursor=pointer]:
      - /url: /
    - navigation [ref=e6]:
      - link "Giỏ hàng" [ref=e7] [cursor=pointer]:
        - /url: /cart
      - generic [ref=e8]:
        - link "Chào, Test User" [ref=e9] [cursor=pointer]:
          - /url: /profile
        - button "Thoát" [ref=e10] [cursor=pointer]
  - main [ref=e11]:
    - generic [ref=e12]:
      - generic [ref=e13]:
        - heading "Hồ sơ của bạn" [level=2] [ref=e14]
        - generic [ref=e15]:
          - generic [ref=e16]:
            - generic [ref=e17]: Email (Không đổi)
            - textbox [disabled] [ref=e18]: test@eshop.com
          - generic [ref=e19]:
            - generic [ref=e20]: Họ Tên
            - textbox [ref=e21]: Test User
          - generic [ref=e22]:
            - generic [ref=e23]: Số điện thoại
            - 'textbox "VD: 0912345678" [ref=e24]'
          - generic [ref=e25]:
            - generic [ref=e26]: Địa chỉ giao hàng
            - textbox "Nhập địa chỉ của bạn" [ref=e27]
          - button "Cập nhật" [ref=e28] [cursor=pointer]
      - generic [ref=e29]:
        - heading "Lịch sử đơn hàng" [level=2] [ref=e30]
        - table [ref=e31]:
          - rowgroup [ref=e32]:
            - row [ref=e33]:
              - columnheader "Mã ĐH" [ref=e34]
              - columnheader "Ngày đặt" [ref=e35]
              - columnheader "Tổng tiền" [ref=e36]
              - columnheader "Trạng thái" [ref=e37]
              - columnheader "Thao tác" [ref=e38]
          - rowgroup [ref=e39]:
            - row [ref=e40]:
              - cell "#9" [ref=e41]
              - cell "8/10/2026" [ref=e42]
              - cell "0 ₫" [ref=e43]
              - cell "Chờ xác nhận" [ref=e44]
              - cell [ref=e45]:
                - button "Hủy đơn" [ref=e46] [cursor=pointer]
            - row [ref=e47]:
              - cell "#8" [ref=e48]
              - cell "8/10/2026" [ref=e49]
              - cell "-1,000,000 ₫" [ref=e50]
              - cell "Chờ xác nhận" [ref=e51]
              - cell [ref=e52]:
                - button "Hủy đơn" [ref=e53] [cursor=pointer]
            - row [ref=e54]:
              - cell "#7" [ref=e55]
              - cell "8/10/2026" [ref=e56]
              - cell "0 ₫" [ref=e57]
              - cell "Chờ xác nhận" [ref=e58]
              - cell [ref=e59]:
                - button "Hủy đơn" [ref=e60] [cursor=pointer]
            - row [ref=e61]:
              - cell "#6" [ref=e62]
              - cell "8/10/2026" [ref=e63]
              - cell "NaN ₫" [ref=e64]
              - cell "Chờ xác nhận" [ref=e65]
              - cell [ref=e66]:
                - button "Hủy đơn" [ref=e67] [cursor=pointer]
            - row [ref=e68]:
              - cell "#5" [ref=e69]
              - cell "8/10/2026" [ref=e70]
              - cell "1,000,000 ₫" [ref=e71]
              - cell "Đã giao" [ref=e72]
              - cell [ref=e73]
            - row [ref=e74]:
              - cell "#4" [ref=e75]
              - cell "8/10/2026" [ref=e76]
              - cell "1,000,000 ₫" [ref=e77]
              - cell "Đã hủy" [ref=e78]
              - cell [ref=e79]
            - row [ref=e80]:
              - cell "#2" [ref=e81]
              - cell "8/10/2026" [ref=e82]
              - cell "1,000,000 ₫" [ref=e83]
              - cell "Đã hủy" [ref=e84]
              - cell [ref=e85]
            - row [ref=e86]:
              - cell "#1" [ref=e87]
              - cell "8/10/2026" [ref=e88]
              - cell "1,000,000 ₫" [ref=e89]
              - cell "Đã hủy" [ref=e90]
              - cell [ref=e91]
  - contentinfo [ref=e92]: © 2026 EShop SUT. Dành cho mục đích kiểm thử.
```

# Test source

```ts
  715 |             new Set(classes).size,
  716 |             `${row.tc_id}: the five statuses do not render in ${row.expect_distinct_badge_count} ` +
  717 |             `distinct colours - got ${JSON.stringify(classes)}`,
  718 |           ).toBe(row.expect_distinct_badge_count);
  719 |           break;
  720 |         }
  721 | 
  722 |         case 'cancel_visibility': {
  723 |           const counts = await Promise.all(
  724 |             seededIds.map((id) => orderHistoryPage.cancelButton(id).count()),
  725 |           );
  726 |           const shown = counts.filter((c) => c > 0).length;
  727 |           expect(
  728 |             shown,
  729 |             `${row.tc_id}: cancel offered on ${shown} of the ${seededIds.length} seeded ` +
  730 |             `statuses, expected ${row.expect_cancel_count}`,
  731 |           ).toBe(row.expect_cancel_count);
  732 |           break;
  733 |         }
  734 | 
  735 |         case 'ordering': {
  736 |           // Pattern 3. Asserted on the id column: the date column cannot witness this -
  737 |           // see expectSortedDescByNumber for the measured reason.
  738 |           const ids = await orderHistoryPage.orderIds();
  739 |           expectSortedDescByNumber(ids, `${row.tc_id} ${row.expect_sorted_desc_by}`);
  740 |           // And the ids this run seeded must appear newest-first among themselves.
  741 |           const seededInOrder = ids.filter((id) => seededIds.includes(id));
  742 |           expect(
  743 |             seededInOrder,
  744 |             `${row.tc_id}: the orders seeded by this run are not newest-first`,
  745 |           ).toEqual([...seededIds].reverse());
  746 |           break;
  747 |         }
  748 | 
  749 |         case 'date_valid': {
  750 |           const orderId = seededIds[0];
  751 |           const rendered = (await orderHistoryPage.cellOf(orderId, 2).innerText()).trim();
  752 | 
  753 |           // Pattern 1: the cell must say something, and must not say "Invalid Date".
  754 |           expect(rendered, `${row.tc_id}: date cell is empty`).not.toBe('');
  755 |           expect(rendered, `${row.tc_id}: date rendered as "Invalid Date"`).not.toContain('Invalid');
  756 | 
  757 |           /*
  758 |            * Pattern 3: the cell must be THIS order's date.
  759 |            *
  760 |            * Deliberately NOT `Date.parse(rendered)`. `toLocaleDateString()` emits a
  761 |            * localized string, and Node's parser reads `10/08/2026` as 10 August in
  762 |            * en-US order while the engine may have written it as 8 October - so the
  763 |            * check would either fail on a correct date or pass on a wrong one,
  764 |            * differently per browser. That is a false-fail generator across the three
  765 |            * required engines, not a test.
  766 |            *
  767 |            * Instead: take `created_at` from the API, split it into calendar parts IN
  768 |            * THE BROWSER (its timezone is what the rendering used), and require the
  769 |            * cell to contain each part. Comparing parts rather than a formatted string
  770 |            * is order-agnostic, so dd/MM/yyyy and M/d/yyyy both satisfy it while a
  771 |            * genuinely wrong date does not.
  772 |            */
  773 |           const seeded = (await api.myOrders(request, ownerToken)).find((o) => o.id === orderId);
  774 |           expect(seeded, `${row.tc_id}: seeded order #${orderId} not returned by my-orders`)
  775 |             .toBeDefined();
  776 | 
  777 |           const parts = await page.evaluate((createdAt: string) => {
  778 |             const date = new Date(createdAt);
  779 |             return Number.isNaN(date.getTime()) ? null : {
  780 |               year: String(date.getFullYear()),
  781 |               month: String(date.getMonth() + 1),
  782 |               day: String(date.getDate()),
  783 |             };
  784 |           }, seeded!.created_at);
  785 | 
  786 |           expect(
  787 |             parts,
  788 |             `${row.tc_id}: the browser cannot parse created_at "${seeded!.created_at}" at all, ` +
  789 |             `so the rendered cell cannot be correct either`,
  790 |           ).not.toBeNull();
  791 | 
  792 |           for (const [name, value] of Object.entries(parts!)) {
  793 |             // Zero-padded and unpadded forms both count: "8" must match "08".
  794 |             const padded = value.padStart(2, '0');
  795 |             expect(
  796 |               rendered.includes(value) || rendered.includes(padded),
  797 |               `${row.tc_id}: date cell "${rendered}" does not contain the ${name} ` +
  798 |               `(${value}) of this order's created_at "${seeded!.created_at}"`,
  799 |             ).toBe(true);
  800 |           }
  801 |           break;
  802 |         }
  803 | 
  804 |         case 'money_render': {
  805 |           const rendered = (await orderHistoryPage.cellOf(seededIds[0], 3).innerText()).trim();
  806 |           if (row.expect_money_text !== undefined) {
  807 |             expect(rendered, `${row.tc_id}: money cell`).toBe(row.expect_money_text);
  808 |           }
  809 |           if (row.expect_money_not !== undefined) {
  810 |             expect(
  811 |               rendered,
  812 |               `${row.tc_id}: money cell renders "${rendered}", which must not contain ` +
  813 |               `"${row.expect_money_not}" - the seeded total was ` +
  814 |               `${JSON.stringify(row.seed_owner_orders![0].total_amount)}`,
> 815 |             ).not.toContain(row.expect_money_not);
      |                   ^ Error: FR11-TC-34: money cell renders "0 ₫", which must not contain "0 ₫" - the seeded total was null
  816 |           }
  817 |           break;
  818 |         }
  819 | 
  820 |         case 'cancel_click': {
  821 |           const id = seededIds[0];
  822 |           const buttonCount = await orderHistoryPage.cancelButton(id).count();
  823 |           const cancelResponse = buttonCount > 0
  824 |             ? page.waitForResponse((response) =>
  825 |               response.url().includes(`/api/orders/${id}/cancel`)
  826 |               && response.request().method() === 'PUT')
  827 |             : undefined;
  828 |           const refreshedHistory = buttonCount > 0
  829 |             ? page.waitForResponse((response) =>
  830 |               response.url().includes('/api/orders/my-orders')
  831 |               && response.request().method() === 'GET')
  832 |             : undefined;
  833 | 
  834 |           if (row.expect_cancel_allowed) {
  835 |             expect(
  836 |               buttonCount,
  837 |               `${row.tc_id}: no cancel button on an order that should be cancellable`,
  838 |             ).toBe(1);
  839 |             await orderHistoryPage.cancelButton(id).click();
  840 |             if (row.expect_dialog !== undefined) {
  841 |               await expect
  842 |                 .poll(() => dialogs, { message: `${row.tc_id}: no confirmation was shown` })
  843 |                 .toContain(row.expect_dialog);
  844 |             }
  845 |           } else if (buttonCount > 0) {
  846 |             // The requirement says this must be refused; the button being here at all is
  847 |             // already the symptom, so the click is what proves whether it is enforced.
  848 |             await orderHistoryPage.cancelButton(id).click();
  849 |           }
  850 | 
  851 |           // The badge initially contains the expected pre-cancel value. Without waiting
  852 |           // for the endpoint, toHaveText(oldValue) can pass immediately before the SUT
  853 |           // applies the mutation and refreshes the list (observed on Chromium/Firefox,
  854 |           // while faster WebKit exposed the cancellation). Synchronise on the business
  855 |           // request, not on an arbitrary delay.
  856 |           if (cancelResponse) await cancelResponse;
  857 |           if (refreshedHistory) await refreshedHistory;
  858 | 
  859 |           // Pattern 1 + 3: what the row says afterwards is the requirement, whichever
  860 |           // route got us here - a refusal that still cancels the order fails here.
  861 |           await expect(
  862 |             orderHistoryPage.statusBadge(id),
  863 |             `${row.tc_id}: status after the cancel attempt (dialogs seen: ` +
  864 |             `${JSON.stringify(dialogs)})`,
  865 |           ).toHaveText(row.expect_label_after!);
  866 |           break;
  867 |         }
  868 | 
  869 |         case 'status_after_transition':
  870 |           await expect(
  871 |             orderHistoryPage.statusBadge(seededIds[0]),
  872 |             `${row.tc_id}: an order the user cancelled must not display as ` +
  873 |             `"${row.set_status}"`,
  874 |           ).toHaveText(row.expect_label_after!);
  875 |           if (row.expect_badge_class) {
  876 |             const badgeClass = await orderHistoryPage.badgeClassOf(seededIds[0]);
  877 |             for (const token of row.expect_badge_class.split(' ')) {
  878 |               expect(badgeClass, `${row.tc_id}: badge colour after the transition`).toContain(token);
  879 |             }
  880 |           }
  881 |           break;
  882 | 
  883 |         case 'load_error':
  884 |           if (row.intercept === 'my_orders_500') {
  885 |             // The requirement: a failure must be reported as a failure. Profile.jsx's
  886 |             // catch does setOrders([]), so the empty state is what actually appears -
  887 |             // asserting it must NOT appear is the falsifiable form of the requirement.
  888 |             await expect(
  889 |               orderHistoryPage.emptyState,
  890 |               `${row.tc_id}: the order fetch failed with 500, but the page tells the user ` +
  891 |               `they have no orders - an error is indistinguishable from an empty history`,
  892 |             ).toBeHidden();
  893 |           } else {
  894 |             // The fallback branch must render the payload it was given.
  895 |             await expect(
  896 |               orderHistoryPage.rowFor(424242),
  897 |               `${row.tc_id}: the documented res.data.orders fallback did not render`,
  898 |             ).toHaveCount(1);
  899 |           }
  900 |           break;
  901 | 
  902 |         case 'malformed_payload':
  903 |           await expect(
  904 |             orderHistoryPage.heading,
  905 |             `${row.tc_id}: malformed orders payload crashed the profile instead of ` +
  906 |             `showing a controlled error state`,
  907 |           ).toBeVisible();
  908 |           await expect(
  909 |             orderHistoryPage.emptyState,
  910 |             `${row.tc_id}: malformed data must not be presented as a genuine empty history`,
  911 |           ).toBeHidden();
  912 |           break;
  913 | 
  914 |         case 'own_rows_and_isolation':
  915 |           break; // handled above, where the payload is still in scope
```