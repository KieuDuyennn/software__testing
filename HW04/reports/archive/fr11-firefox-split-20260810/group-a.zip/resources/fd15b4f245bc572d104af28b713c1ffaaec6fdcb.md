# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: fr11_order_history\fr11.order-history.spec.ts >> FR-11 Order history view >> FR11-TC-19 [negative] a non-admin user must not be able to change an order's status
- Location: automation\tests\fr11_order_history\fr11.order-history.spec.ts:320:5

# Error details

```
Error: FR11-TC-19 set status: http://localhost:3000/api/admin/orders/34/status answered 200, expected one of [401, 403]. Body: {"message":"Order status updated"}

expect(received).toContain(expected) // indexOf

Expected value: 200
Received array: [401, 403]
```

```
Error: FR11-TC-19: status was changed to "confirmed" despite the refusal

expect(received).toBe(expected) // Object.is equality

Expected: "pending"
Received: "confirmed"
```

# Test source

```ts
  334 |         otherIds.push(await api.checkout(request, await ensureOther(), 2_000_000));
  335 |       }
  336 | 
  337 |       /* ---------------- API channel ---------------- */
  338 | 
  339 |       if (row.channel === 'api') {
  340 |         const tokenFor = async (): Promise<string | null> => {
  341 |           switch (row.acting_as) {
  342 |             case 'owner': return ownerToken;
  343 |             case 'admin': return adminToken;
  344 |             case 'other': return ensureOther();
  345 |             case 'none': return null;
  346 |             case 'ghost':
  347 |               return api.mintToken(SUT_JWT_SECRET, { id: 2_147_483_647, role: 'user' });
  348 |             default:
  349 |               throw new Error(`${row.tc_id}: acting_as "${row.acting_as}" is not a known identity`);
  350 |           }
  351 |         };
  352 |         const token = await tokenFor();
  353 | 
  354 |         // Race cases use a status multiset instead of one allowed-status list. Keep
  355 |         // this shared flag false for that branch; every denial branch is guarded by
  356 |         // data validation that requires expect_http_any_of.
  357 |         const expectsDenial = row.expect_http_any_of !== undefined
  358 |           && !row.expect_http_any_of.includes(200);
  359 | 
  360 |         /**
  361 |          * Every status assertion in this branch is SOFT, on purpose.
  362 |          *
  363 |          * A hard `expect` throws, so when a denial case is answered `200` - which is
  364 |          * what 6 of these rows are predicted to do - the assertion aborts the test
  365 |          * before the follow-up check runs, and the report says only "expected 403, got
  366 |          * 200". The far more serious facts (the record was disclosed; the status was
  367 |          * written anyway) would never be collected. Soft failures still fail the test,
  368 |          * so nothing is weakened: both statements land in the same report. Same
  369 |          * reasoning as finding 3, which is where this pattern came from.
  370 |          */
  371 |         switch (row.api_call) {
  372 |           case 'order_detail': {
  373 |             // The id is either written literally in the data file (the malformed and
  374 |             // boundary probes) or resolved from what this run seeded.
  375 |             const id = row.detail_order_id ?? (
  376 |               row.detail_owned_by === 'other' ? String(otherIds[0]) : String(seededIds[0])
  377 |             );
  378 |             const response = await api.orderDetailRaw(request, token, id);
  379 |             // Evidence first, assertion second: reading the body cannot be skipped by a
  380 |             // status assertion that throws.
  381 |             const disclosed = response.status() === 200 ? await response.json() : null;
  382 | 
  383 |             await expectStatusAmong(
  384 |               response, row.expect_http_any_of!, `${row.tc_id} order detail`, { soft: true },
  385 |             );
  386 | 
  387 |             // Pattern 3: a refusal that still ships the record is not a refusal.
  388 |             if (expectsDenial && disclosed !== null) {
  389 |               expect(
  390 |                 disclosed,
  391 |                 `${row.tc_id}: the request was refused-by-requirement yet the order record ` +
  392 |                 `was returned in full - fields: ${Object.keys(disclosed).join(', ')}`,
  393 |               ).not.toHaveProperty('total_amount');
  394 |             }
  395 |             break;
  396 |           }
  397 | 
  398 |           case 'admin_orders_list': {
  399 |             const response = await api.adminOrdersListRaw(request, token!);
  400 |             const leaked = response.status() === 200 ? await response.json() : null;
  401 | 
  402 |             await expectStatusAmong(
  403 |               response, row.expect_http_any_of!, `${row.tc_id} admin order list`, { soft: true },
  404 |             );
  405 | 
  406 |             // Pattern 3: scale is the finding here. "A non-admin got 200" understates it
  407 |             // if the body was every order in the database, with each owner's name.
  408 |             if (expectsDenial && Array.isArray(leaked)) {
  409 |               expect(
  410 |                 leaked.length,
  411 |                 `${row.tc_id}: a non-admin account was served ${leaked.length} orders ` +
  412 |                 `belonging to other users`,
  413 |               ).toBe(0);
  414 |             }
  415 |             break;
  416 |           }
  417 | 
  418 |           case 'admin_set_status': {
  419 |             const response = await api.setStatusRaw(request, token!, seededIds[0], row.set_status!);
  420 |             await expectStatusAmong(
  421 |               response, row.expect_http_any_of!, `${row.tc_id} set status`, { soft: true },
  422 |             );
  423 | 
  424 |             // Pattern 3: a refused transition must also have left the row alone. A 400
  425 |             // that still wrote the new status would pass on the code alone. The
  426 |             // conditional guard makes transition_from mandatory on these rows, so the
  427 |             // check can never be silently skipped.
  428 |             if (expectsDenial) {
  429 |               const after = (await api.myOrders(request, ownerToken))
  430 |                 .find((o) => o.id === seededIds[0]);
  431 |               expect(
  432 |                 after?.status,
  433 |                 `${row.tc_id}: status was changed to "${row.set_status}" despite the refusal`,
> 434 |               ).toBe(row.transition_from);
      |                 ^ Error: FR11-TC-19: status was changed to "confirmed" despite the refusal
  435 |             }
  436 |             break;
  437 |           }
  438 | 
  439 |           case 'order_cancel': {
  440 |             const targetIsOther = row.cancel_owned_by === 'other';
  441 |             const target = targetIsOther ? otherIds[0] : seededIds[0];
  442 |             const response = await api.cancelRaw(request, token, target);
  443 |             await expectStatusAmong(
  444 |               response, row.expect_http_any_of!, `${row.tc_id} cancel`, { soft: true },
  445 |             );
  446 | 
  447 |             // Pattern 3: the order must still hold the status it had. Read through the
  448 |             // account that actually OWNS it - my-orders filters on user_id, so asking
  449 |             // with the owner's token for `other`'s order returns nothing and the check
  450 |             // would silently pass on `undefined`.
  451 |             if (expectsDenial) {
  452 |               const readerToken = targetIsOther ? await ensureOther() : ownerToken;
  453 |               const after = (await api.myOrders(request, readerToken))
  454 |                 .find((o) => o.id === target);
  455 |               expect(
  456 |                 after,
  457 |                 `${row.tc_id}: order #${target} is not visible to its own owner, so the ` +
  458 |                 `integrity check cannot run - the fixture is wrong, not the SUT`,
  459 |               ).toBeDefined();
  460 |               expect(
  461 |                 after?.status,
  462 |                 `${row.tc_id}: order #${target} was cancelled despite the request being ` +
  463 |                 `refused${targetIsOther ? ' - and it belongs to another user' : ''}`,
  464 |               ).toBe(row.cancel_target_status);
  465 |             }
  466 |             break;
  467 |           }
  468 | 
  469 |           case 'order_cancel_race': {
  470 |             const target = seededIds[0];
  471 |             const responses = await Promise.all([
  472 |               api.cancelRaw(request, token, target),
  473 |               api.cancelRaw(request, token, target),
  474 |             ]);
  475 |             const actual = responses.map((response) => response.status()).sort((a, b) => a - b);
  476 |             const expected = [...row.expect_http_multiset!].sort((a, b) => a - b);
  477 |             expect(
  478 |               actual,
  479 |               `${row.tc_id}: two simultaneous cancel requests must produce one success and ` +
  480 |               `one refusal, not acknowledge the same state transition twice`,
  481 |             ).toEqual(expected);
  482 |             const after = (await api.myOrders(request, ownerToken)).find((o) => o.id === target);
  483 |             expect(after?.status, `${row.tc_id}: final status after the race`)
  484 |               .toBe(row.expect_final_status);
  485 |             break;
  486 |           }
  487 | 
  488 |           case 'checkout': {
  489 |             const response = await api.checkoutRaw(request, ownerToken, row.checkout_total_amount);
  490 |             await expectStatusAmong(
  491 |               response, row.expect_http_any_of!, `${row.tc_id} checkout`, { soft: true },
  492 |             );
  493 | 
  494 |             // Pattern 3: a rejected checkout must not have created an order. Otherwise a
  495 |             // 400 that writes the row anyway passes on the status alone.
  496 |             if (expectsDenial && response.status() === 200) {
  497 |               const body = await response.json();
  498 |               const created = (await api.myOrders(request, ownerToken))
  499 |                 .find((o) => o.id === body.orderId);
  500 |               expect(
  501 |                 created,
  502 |                 `${row.tc_id}: checkout accepted total_amount ` +
  503 |                 `${JSON.stringify(row.checkout_total_amount)} and created order ` +
  504 |                 `#${body.orderId}, whose stored total is ` +
  505 |                 `${JSON.stringify(created?.total_amount)}`,
  506 |               ).toBeUndefined();
  507 |             }
  508 |             break;
  509 |           }
  510 | 
  511 |           case 'my_orders': {
  512 |             const response = await api.myOrdersRaw(request, token);
  513 |             await expectStatusAmong(
  514 |               response, row.expect_http_any_of!, `${row.tc_id} my-orders`, { soft: true },
  515 |             );
  516 |             if (!row.expect_http_any_of!.includes(200) && response.status() === 200) {
  517 |               const body = await response.json();
  518 |               expect(
  519 |                 body,
  520 |                 `${row.tc_id}: a correctly signed token for a user that does not exist ` +
  521 |                 `was accepted as a live session and received an order-history payload`,
  522 |               ).toBeNull();
  523 |             }
  524 |             break;
  525 |           }
  526 | 
  527 |           default:
  528 |             throw new Error(`${row.tc_id}: api_call "${row.api_call}" is not a known endpoint`);
  529 |         }
  530 |         return;
  531 |       }
  532 | 
  533 |       /* ---------------- UI channel ---------------- */
  534 | 
```