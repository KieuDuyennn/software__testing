# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: fr11_order_history\fr11.order-history.spec.ts >> FR-11 Order history view >> FR11-TC-12 [positive] a delivered order renders as Đã giao with the green badge and no cancel button
- Location: automation\tests\fr11_order_history\fr11.order-history.spec.ts:320:5

# Error details

```
SyntaxError: Unexpected token 'T', "Too many r"... is not valid JSON
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - link "EShop" [ref=e5] [cursor=pointer]:
      - /url: /
    - navigation [ref=e6]:
      - link "Giỏ hàng" [ref=e7] [cursor=pointer]:
        - /url: /cart
      - link "Đăng nhập" [ref=e8] [cursor=pointer]:
        - /url: /login
      - link "Đăng ký" [ref=e9] [cursor=pointer]:
        - /url: /register
  - main [ref=e10]:
    - generic [ref=e11]: Vui lòng đăng nhập
  - contentinfo [ref=e12]: © 2026 EShop SUT. Dành cho mục đích kiểm thử.
```

# Test source

```ts
  1   | import type { Locator, Page, Response } from '@playwright/test';
  2   | import { BasePage } from './BasePage';
  3   | 
  4   | /**
  5   |  * FR-11 Order history view, user side (Pool B).
  6   |  *
  7   |  * The path is `/profile`, NOT `/orders`. `frontend-web/src/App.jsx` declares no
  8   |  * `/orders` route at all; the order history is a panel inside `Profile.jsx`.
  9   |  * HW02 recorded FR-11 as having no web UI because it searched for a route name
  10  |  * instead of the rendered feature - see TC_Matrix_FR11.md.
  11  |  *
  12  |  * Locators derived from `Profile.jsx` and then verified on the running page with
  13  |  * a throwaway probe, against a seeded account holding 16 orders across all five
  14  |  * statuses. The counts:
  15  |  *
  16  |  *   getByRole('heading', {name:'Lịch sử đơn hàng'}) -> 1
  17  |  *   getByRole('table')                             -> 1   (0 when there are no orders)
  18  |  *   getByRole('row')      [whole page]             -> 17  (16 + the header row)
  19  |  *   getByRole('columnheader')                      -> 5
  20  |  *   getByRole('rowgroup')                          -> 2   (thead + tbody)
  21  |  *   table >> tbody tr                              -> 16
  22  |  *   row.locator('span')   [the status badge]       -> 1 per row
  23  |  *   getByRole('button', {name:'Hủy đơn'})          -> 14  (absent on delivered + canceled)
  24  |  *   getByText('Bạn chưa có đơn hàng nào.')         -> 1   (on a zero-order account)
  25  |  *
  26  |  * Column order, read off the rendered page: Mã ĐH · Ngày đặt · Tổng tiền ·
  27  |  * Trạng thái · Thao tác.
  28  |  *
  29  |  * Four things the probe established that change how the assertions must be written:
  30  |  *
  31  |  *   1. `orders` starts as `[]` in Profile.jsx, so "Bạn chưa có đơn hàng nào."
  32  |  *      renders for a moment even for a user who HAS orders, until the fetch
  33  |  *      resolves. Asserting the empty state on a bare goto() can therefore pass
  34  |  *      spuriously. Use gotoAndWaitForOrders(), which waits for the actual
  35  |  *      /api/orders/my-orders response.
  36  |  *   2. Row lookup by order id must match the cell exactly. filter({hasText:'#1'})
  37  |  *      matched 8 rows once ids reached double digits (#1 and #10-#16); ids do
  38  |  *      reach double digits across repeated runs, so the substring form is a
  39  |  *      latent false pass. rowFor() uses exact text.
  40  |  *   3. Every order created in one run shares the same rendered date: created_at
  41  |  *      is a second-granularity SQLite CURRENT_TIMESTAMP and the cell uses
  42  |  *      toLocaleDateString(), which drops the time. 16 orders produced exactly 1
  43  |  *      distinct value in the date column, so newest-first CANNOT be asserted on
  44  |  *      that column. Assert on the Mã ĐH column instead - the backend sorts
  45  |  *      `ORDER BY id DESC` (server.js, /api/orders/my-orders), not by created_at.
  46  |  *   4. The backend's status machine only allows pending -> confirmed -> shipping
  47  |  *      -> delivered, so a `delivered` fixture needs three sequential admin calls.
  48  |  */
  49  | export class OrderHistoryPage extends BasePage {
  50  |   readonly path = '/profile';
  51  | 
  52  |   constructor(page: Page) { super(page); }
  53  | 
  54  |   get heading(): Locator {
  55  |     return this.page.getByRole('heading', { name: 'Lịch sử đơn hàng' });
  56  |   }
  57  | 
  58  |   get table(): Locator { return this.page.getByRole('table'); }
  59  | 
  60  |   /**
  61  |    * CSS last resort: ARIA has no "body row" role - getByRole('row') returns the
  62  |    * header row too, and there is no accessible name on the row group to select
  63  |    * tbody by. Scoping to the table keeps it unambiguous (the page has exactly
  64  |    * one table).
  65  |    */
  66  |   get rows(): Locator { return this.table.locator('tbody tr'); }
  67  | 
  68  |   get emptyState(): Locator {
  69  |     return this.page.getByText('Bạn chưa có đơn hàng nào.');
  70  |   }
  71  | 
  72  |   /** Rendered instead of the whole panel when there is no session. */
  73  |   get notLoggedInMessage(): Locator {
  74  |     return this.page.getByText('Vui lòng đăng nhập');
  75  |   }
  76  | 
  77  |   get columnHeaders(): Locator { return this.page.getByRole('columnheader'); }
  78  | 
  79  |   /**
  80  |    * Navigates and waits for the order fetch to actually come back, so that an
  81  |    * assertion cannot run against the pre-fetch empty state (see note 1 above).
  82  |    * Returns the API payload, which lets a test compare what the API said with
  83  |    * what the table rendered - a data-integrity assertion rather than a second
  84  |    * UI assertion.
  85  |    */
  86  |   async gotoAndWaitForOrders(): Promise<Array<Record<string, unknown>>> {
  87  |     const responsePromise: Promise<Response> = this.page.waitForResponse(
  88  |       (r) => r.url().includes('/api/orders/my-orders'),
  89  |     );
  90  |     await this.goto();
  91  |     const response = await responsePromise;
> 92  |     const body = await response.json();
      |                  ^ SyntaxError: Unexpected token 'T', "Too many r"... is not valid JSON
  93  |     return Array.isArray(body) ? body : (body.orders ?? []);
  94  |   }
  95  | 
  96  |   /**
  97  |    * For the anonymous / bad-token cases: Profile.jsx never issues the request
  98  |    * when there is no usable session, so gotoAndWaitForOrders() would hang.
  99  |    */
  100 |   async gotoWithoutSession(): Promise<void> {
  101 |     await this.goto();
  102 |     await this.waitForReady();
  103 |   }
  104 | 
  105 |   /** Exact-match row lookup - see note 2 above on why hasText is unsafe here. */
  106 |   rowFor(orderId: number | string): Locator {
  107 |     return this.rows.filter({
  108 |       has: this.page.getByText(`#${orderId}`, { exact: true }),
  109 |     });
  110 |   }
  111 | 
  112 |   /**
  113 |    * CSS last resort: the status badge is a <span> with no role, no accessible
  114 |    * name and no test id. There is exactly one span per row, so scoping to the
  115 |    * row is enough to identify it without relying on a column index.
  116 |    */
  117 |   statusBadge(orderId: number | string): Locator {
  118 |     return this.rowFor(orderId).locator('span');
  119 |   }
  120 | 
  121 |   /** The Tailwind classes are the only expression of the colour requirement. */
  122 |   async badgeClassOf(orderId: number | string): Promise<string> {
  123 |     return (await this.statusBadge(orderId).getAttribute('class')) ?? '';
  124 |   }
  125 | 
  126 |   cancelButton(orderId: number | string): Locator {
  127 |     return this.rowFor(orderId).getByRole('button', { name: 'Hủy đơn' });
  128 |   }
  129 | 
  130 |   /**
  131 |    * One cell of one row.
  132 |    *
  133 |    * CSS last resort for the same reason as columnValues(): `getByRole('cell')`
  134 |    * would resolve to all five cells of the row with no accessible name to pick
  135 |    * one by, and the column headers are not programmatically associated with the
  136 |    * cells (`<th>` carries no scope attribute), so there is no ARIA route from a
  137 |    * header name to its column.
  138 |    *
  139 |    * @param column 1-based: 1 Mã ĐH · 2 Ngày đặt · 3 Tổng tiền · 4 Trạng thái · 5 Thao tác
  140 |    */
  141 |   cellOf(orderId: number | string, column: number): Locator {
  142 |     return this.rowFor(orderId).locator(`td:nth-child(${column})`);
  143 |   }
  144 | 
  145 |   /**
  146 |    * CSS last resort: reading one column means taking the nth cell of every row.
  147 |    * `rows.locator('td').nth(i)` does NOT do that - it flattens all cells across
  148 |    * all rows and returns a single element (the probe returned 1 value for a
  149 |    * 16-row table), so the nth-child form is required.
  150 |    *
  151 |    * @param column 1-based, matching the rendered order:
  152 |    *   1 Mã ĐH · 2 Ngày đặt · 3 Tổng tiền · 4 Trạng thái · 5 Thao tác
  153 |    */
  154 |   async columnValues(column: number): Promise<string[]> {
  155 |     const cells = await this.rows.locator(`td:nth-child(${column})`).allInnerTexts();
  156 |     return cells.map((text) => text.trim());
  157 |   }
  158 | 
  159 |   /** Order ids as numbers, for the ordering assertion. "#16" -> 16. */
  160 |   async orderIds(): Promise<number[]> {
  161 |     const values = await this.columnValues(1);
  162 |     return values.map((value) => Number(value.replace('#', '')));
  163 |   }
  164 | 
  165 |   async dateColumn(): Promise<string[]> { return this.columnValues(2); }
  166 |   async amountColumn(): Promise<string[]> { return this.columnValues(3); }
  167 |   async statusColumn(): Promise<string[]> { return this.columnValues(4); }
  168 | }
  169 | 
```